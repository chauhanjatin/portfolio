import React from 'react'
import Contactus from './Contactus'

export default function Hireme() {
  return (
    <div>
      <Contactus></Contactus>
    </div>
  )
}